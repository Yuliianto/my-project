<!DOCTYPE html>
<html>
<head>
	<title>antrian</title>
	<style type="text/css">
		.input {
			width: 100%;
		}
		button{
			width: 100%;
			height: 50px;
			font-size: 18pt;
		}
	</style>
</head>
<body>
	<?php
		$antrian = 0;
		if (isset($_POST['start'])) {
			$antrian = $_POST['start'];
		}
		$tampil = $antrian;
		if (isset($_POST['btn'])) {
			if ($_POST['btn']=='next') {
				$antrian +=1;
				$tampil = $antrian;
			}elseif ($_POST['btn']=='prev') {
				$antrian -=1;
				if ($antrian < 0) { 
				 	$antrian +=1;
				 	echo "<i onload=\"javascript:alert('Udah Sepi Bro!!')\"></i>"; 
				}else{
				$tampil = $antrian;
			}
			}
		}
	 ?>

<audio id="myAudio">
  <source src="Airport_Bell.mp3" type="audio/mpeg">
  Your browser does not support the audio element.
</audio>
<audio id="noUrut" src="rekaman/nomor-urut.wav" >
</audio>
	<form action="" method="POST">
		<table border="0">
			<tr>
				<td colspan="2">
					<input id="nomer" class="input" type="text" name="start" value="<?php echo $tampil; ?>">
				</td>
				<td rowspan="2"><?php echo $tampil; ?></td>
			</tr>
			<tr>
				<td>
					<button value="prev"  name="btn">Prev</button>
				</td>
				<td>
					<button value="next" name="btn">Next</button>
				</td>
			</tr>
		</table>
	</form>
 	<button name="btn" value="" onclick="panggil(<?php echo $tampil; ?>)">panggil</button>
	<script type="text/javascript" src="queue.js">
		panggil();
	</script>
</body>
</html>