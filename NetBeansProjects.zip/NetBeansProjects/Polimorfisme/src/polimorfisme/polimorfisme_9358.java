/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfisme;

/**
 *
 * @author Ulfa
 */
import java.util.Scanner;
public class polimorfisme_9358 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        KaryawanTetap kr_t = new KaryawanTetap();
        KaryawanKontrak kr_k = new KaryawanKontrak();
        System.out.println("========= T E T A P ========");
        System.out.print("Nama\t : "); kr_t.setNama(input.next());
        System.out.print("NIK\t : ");kr_t.setNik(input.next());
        System.out.print("Tunjangan: "); kr_t.setTunjangan(input.nextInt());
        System.out.print("Bonus\t : ");kr_t.setBonus(input.nextInt());
        System.out.println("");
        System.out.println("DATA-OUTPUT:");
        System.out.println("___________________________");
        System.out.println("========= T E T A P ========");
        System.out.println("Nama\t : "+ kr_t.getNama());
        System.out.println("NIK\t : "+kr_t.getNik());
        System.out.println("Tunjangan: "+ kr_t.getTunjangan());
        System.out.println("Bonus\t : "+kr_t.getBonus());
        System.out.println("");
        System.out.println("========= K O N T R A K ========");
        System.out.print("Nama\t : ");kr_k.setNama(input.next());
        System.out.print("NIK\t : ");kr_k.setNik(input.next());
        System.out.print("Bonus\t : ");kr_k.setBonus(input.nextInt());
        System.out.println("");
        System.out.println("______________________________");
        System.out.println("========= K O N T R A K ========");
        System.out.println("Nama\t : "+ kr_k.getNama());
        System.out.println("NIK\t : "+kr_k.getNik());
        System.out.println("Bonus\t : "+kr_k.getBonus());
    }
}
