/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfisme;

/**
 *
 * @author ulfa
 */
public class KaryawanTetap extends Karyawan{
    Integer tunjangan;
    Integer bonus;
    
    public Integer getTunjangan() {
        return tunjangan;
    }
    public void setTunjangan(Integer tunjangan) {
        this.tunjangan = tunjangan;
    }

    public Integer getBonus() {
        return bonus;
    }

    public void setBonus(Integer bonus) {
        this.bonus = bonus;
    }
}
