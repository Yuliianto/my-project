/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan;

/**
 *
 * @author yulianto
 */
public class Latihan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[][] number ={{1,2,3},
                        {4,5,6},
                        {7,8,9}};
        int searchNum = 5;
        boolean foundNum = false;
        
        searchLabel:
        for (int i = 0; i < number.length; i++) {
            for (int j = 0; j < number[i].length; j++) {
                foundNum = true;
                break searchLabel;
            }
        }
        if (foundNum) {
            System.out.println(searchNum+"Found!");
        }else{
            System.out.println(searchNum+"Not Found!");
        }
    }
    
}
