/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasjava259;

/**
 *
 * @author yulianto
 */
import java.io.IOException;
import java.util.Scanner;
public class Main_Kal {
    
    public static void main(String[] args){
        
        Kalkulator kal = new Kalkulator();
        Scanner input = new Scanner(System.in);
        
        int nil1,nil2=0;
        System.out.print("Masukan Nilai Pertama :");
        nil1 = input.nextInt();
        System.out.print("Masukan Nilai Kedua :");
        nil2 = input.nextInt();
        kal.setNil1(nil1);
        kal.setNil2(nil2);
        //Output Hasil 
        System.out.println("Hasil Perkalian dari "+kal.getNil1()+" dan "+kal.getNil2()+" = "+kal.perkalian());
        System.out.println("Hasil Pembagian dari "+kal.getNil1()+" dan "+kal.getNil2()+" = "+kal.pembagian());
        System.out.println("Hasil Penambahan dari "+kal.getNil1()+" dan "+kal.getNil2()+" = "+kal.penambahan());
        System.out.println("Hasil Pengurangan dari "+kal.getNil1()+" dan "+kal.getNil2()+" = "+kal.pengurangan());
    }
}
