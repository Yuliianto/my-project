/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasjava259;

/**
 *
 * @author yulianto
 */
public class Kalkulator {
    //Atribut
    public int nil1 = 0;
    public int nil2 = 0;
    //Mutator
    public void setNil1(int nil){
        this.nil1 = nil;
    }
    public void setNil2(int nil){
        this.nil2 = nil;
    }
    //Accesor
    public int getNil1(){
        return this.nil1;
    }
    public int getNil2(){
        return this.nil2;
    }
    //Method
    public int perkalian(){
        return this.getNil1()*this.getNil2();
    }
    public float pembagian(){
        return this.getNil1()/this.getNil2();
    }
    public int penambahan(){
        return this.getNil1()+this.getNil2();
    }
    public int pengurangan(){
        return this.getNil1()-this.getNil2();
    }
}
