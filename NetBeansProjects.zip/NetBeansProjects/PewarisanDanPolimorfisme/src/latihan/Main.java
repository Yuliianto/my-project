/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package latihan;

/**
 *
 * @author lk3no12uty
 */
public class Main {
    public static void main(String[] args) {
        Person person = new Person();
        Dosen dosen = new Dosen();
        Mahasiswa mhs = new Mahasiswa();
        
        dosen.setIdDosen("123");
        dosen.setNama("Budi");
        dosen.setAlamat("Jakarta");
        dosen.setUmur(30);
        
        mhs.setNIM("456");
        mhs.setNama("Joko");
        mhs.setAlamat("Yogya");
        mhs.setUmur(21);
        
        System.out.println("DOSEN :");
        System.out.println("=================================");
        System.out.println("\tIdDosen \t: "+dosen.getIdDosen());
        System.out.println("\tNama \t: "+dosen.getNama());
        System.out.println("\tAlamat \t:"+dosen.getAlamat());
        System.out.println("\tUmur \t:"+dosen.getUmur());
        
        System.out.println("MAHASISWA :");
        System.out.println("=================================");
        System.out.println("\tIdDosen \t: "+mhs.getNIM());
        System.out.println("\tNama \t: "+mhs.getNama());
        System.out.println("\tAlamat \t:"+mhs.getAlamat());
        System.out.println("\tUmur \t:"+mhs.getUmur());
    }
    
}
