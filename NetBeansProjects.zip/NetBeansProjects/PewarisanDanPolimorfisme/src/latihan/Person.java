/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package latihan;

/**
 *
 * @author lk3no12uty
 */
public class Person {
    private String Nama;
    private String Alamat;
    private Integer Umur;

    public String getNama() {
        return Nama;
    }

    public void setNama(String Nama) {
        this.Nama = Nama;
    }

    public String getAlamat() {
        return Alamat;
    }

    public void setAlamat(String Alamat) {
        this.Alamat = Alamat;
    }

    public Integer getUmur() {
        return Umur;
    }

    public void setUmur(Integer Umur) {
        this.Umur = Umur;
    }
    
    
}
