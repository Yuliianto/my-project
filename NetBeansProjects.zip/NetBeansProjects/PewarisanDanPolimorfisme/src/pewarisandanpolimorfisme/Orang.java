/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pewarisandanpolimorfisme;

/**
 *
 * @author lk3no12uty
 */
public class Orang {
    private String nama;
    private String alamat;
    public String ambilNama() {
        return nama;
    }

    public void ubahNama(String nama) {
        this.nama = nama;
    }

    public String ambilAlamat() {
        return alamat;
    }

    public void ubahAlamat(String alamat) {
        this.alamat = alamat;
    }
}
