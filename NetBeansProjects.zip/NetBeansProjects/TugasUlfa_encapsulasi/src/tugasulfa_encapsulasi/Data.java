/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasulfa_encapsulasi;

/**
 *
 * @author yulianto
 */
public class Data {
   private String nama;
   private String nim;
   private Integer tugas;
   private Integer kuis;
   private Integer ujian;
   private float hasil;

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public Integer getTugas() {
        return tugas;
    }

    public void setTugas(Integer tugas) {
        this.tugas = tugas;
    }

    public Integer getKuis() {
        return kuis;
    }

    public void setKuis(Integer kuis) {
        this.kuis = kuis;
    }

    public Integer getUjian() {
        return ujian;
    }

    public void setUjian(Integer ujian) {
        this.ujian = ujian;
    }
    
    public void hitungRumus(){
        this.tugas = tugas * 25/100;
        this.kuis = kuis * 35/100;
        this.ujian = ujian * 40/100;
        this.hasil = this.tugas+this.kuis+this.ujian; 
    }
    public float hasil(){
        return this.hasil;
    }
}
