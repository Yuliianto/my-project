/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasulfa_encapsulasi;

import java.util.Scanner;

/**
 *
 * @author ulfa
 */
public class Tugas_enkapsulasi9358 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        tugas_enkapsulasi9358 mhs = new tugas_enkapsulasi9358();
        System.out.println("========================================");
        System.out.print("Input Nama :");
        mhs.setNama(input.nextLine());
        System.out.print("Input Nim :");
        mhs.setNim(input.nextLine());
        System.out.print("Input Nilai Tugas :");
        mhs.setTugas(input.nextInt());
        System.out.print("Input Nilai Kuis:");
        mhs.setKuis(input.nextInt());
        System.out.print("Input Nilai Ujian:");
        mhs.setUjian(input.nextInt());
        System.out.println("========================================");
        
        System.out.println("Nama :"+mhs.getNama());
        System.out.println("Nim  :"+mhs.getNim());
        System.out.println("Nilai Tugas :"+mhs.getTugas());
        System.out.println("Nilai Kuis  :"+mhs.getKuis());
        System.out.println("Nilai Ujian :"+mhs.getUjian());
        System.out.println("====================");
        mhs.hitungRumus();
        System.out.println("Nilai Akhir : "+mhs.hasil());
        
    }
}
