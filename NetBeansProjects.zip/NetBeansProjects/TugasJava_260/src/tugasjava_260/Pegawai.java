/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasjava_260;

/**
 *
 * @author Eko
 */
public class Pegawai {
    //Atribut 
    public String Nama = " ";
    public int NIP =0;
    public int umur = 0;
    public String jabatan = " ";
    //Mutator
    public void setNama(String nama){
        this.Nama = nama;
    }
    public void setNIP(int nip){
        this.NIP = nip;
    }
    public void setUmur(int umur){
        this.umur = umur;
    }
    public void setJabatan(String jabatan){
        this.jabatan = jabatan;
    }
    //Accesor
    public String getNama(){
        return this.Nama;
    }
    public int getNIP(){
        return this.NIP;
    }
    public int getUmur(){
        return this.umur;
    }
    public String getJabatan(){
        return this.jabatan;        
    }
    
}
