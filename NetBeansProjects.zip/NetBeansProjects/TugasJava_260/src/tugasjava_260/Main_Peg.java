/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasjava_260;

/**
 *
 * @author Eko
 */
import java.util.Scanner;
import java.io.EOFException;
public class Main_Peg {
    public static void main(String []args){
        Scanner input = new Scanner(System.in);
    
        Pegawai jesica = new Pegawai();
        Pegawai adri = new Pegawai();
        Pegawai kez = new Pegawai();
        
        //jesica
        jesica.setNama("Jesica Verada");
        jesica.setNIP(123456);
        jesica.setUmur(22);
        jesica.setJabatan("Sekertaris");
        //Adri Priadana
        adri.setNama("Adri Priadana");
        adri.setNIP(123455);
        adri.setUmur(26);
        adri.setJabatan("Direktur");
        //Kezia 
        kez.setNama("Kezia Amalia");
        kez.setNIP(123457);
        kez.setUmur(27);
        kez.setJabatan("Bendahara");
        
        System.out.println(jesica.getNama()+","+jesica.getNIP()+","+jesica.getUmur()+","+jesica.getJabatan());
        System.out.println(adri.getNama()+","+adri.getNIP()+","+adri.getUmur()+","+adri.getJabatan());
        System.out.println(kez.getNama()+","+kez.getNIP()+","+kez.getUmur()+","+kez.getJabatan());
    }
}
