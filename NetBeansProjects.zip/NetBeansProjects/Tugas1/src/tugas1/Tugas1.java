/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1;

/**
 *
 * @author yulianto
 */
import java.io.IOException;
import java.io.Console;
import java.util.Scanner;
public class Tugas1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] item 	= {500000,450000,300000};
		String jawab="y";
		int itemIdx = 0;
		int jml 	= 0;
		int total	= 0;
		Console cs = System.console();
		Scanner input = new Scanner(System.in);

		System.out.println("Kategori sepatu");
		System.out.println("1. Nike \t: Rp. 500.000");
		System.out.println("2. Adidas \t: Rp. 450.000");
		System.out.println("3. Converse \t: Rp. 300.000");

		do{
                    try {
			System.out.print("Masukan merk sepatu : ");
			itemIdx = input.nextInt();
			System.out.print("Masukan jumlah yang dibeli : ");
			jml 	= input.nextInt();
			System.out.print("Apakah ingin menambah belanjaan? (t=tidak/Y=ya) : ");
			jawab		= input.next();
                        
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
			int hasil = item[itemIdx-1]*jml;
			total = total+hasil;
		}while(jawab.equalsIgnoreCase("y"));
		System.out.println("==============================================");
		System.out.println("Yang harus dibayar \t: "+total);
    }
    
}
