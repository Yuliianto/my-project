/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectmysqldb;

/**
 *
 * @author yulianto
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class Koneksi {
    public static Connection con;
    public static Statement stm;
    public static String query;
    public static void main(String[] args) throws SQLException {
        try {
            String url="jdbc:mysql://localhost/indonesia";
            String user="root";
            String pass="";
            Class.forName("com.mysql.jdbc.Driver");
            con= DriverManager.getConnection(url, user, pass);
            stm=con.createStatement();
            System.out.println("Connected!!");
        } catch (Exception e) {
            System.err.println("Failed to Connect!"+e.getMessage());
        }
        ResultSet rs;
        query="select * from provinces";
        rs = stm.executeQuery(query);
        while(rs.next()){
            System.out.println(rs.getString("id")+"|"+rs.getString("name"));
        }
        rs.close();
        con.close();
    }
    
}
