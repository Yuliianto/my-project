<link rel="stylesheet" type="text/css" href="<?= base_url('asset/vendor/dropzone/dropzone.min.css'); ?>">
<style>
		body {
			background: #f7f7f7;
			font-family: 'Montserrat', sans-serif;
		}
	</style>
<div class="container-fluid" style="margin-top: 100px;">
	<div class="row">
		<?php for ($i=0; $i < 4; $i++) { ?>
			<div class="col-3" style="min-width: 320px;">
				<div class="card">
					<div class="card-header bg-primary" style="color: #fff;">
				      	<h4 class="card-title">Card title<b class="fa fa-trash pull-right btn btn-primary"></b></h4>
					</div>
				    <div class="card-body">
				      <p class="card-text">Some example text. Some example text.</p>
				    </div>
				    <div class="card-footer">
				      <a href="#" class="card-link pull-right"><i class="fa fa-folder"></i>&nbsp;&nbsp;</a>
				      <a href="#" class="card-link pull-right"><i class="fa fa-file"></i>&nbsp;&nbsp;</a>
				    </div>
				</div><br>
			</div> 
		<?php } ?>

	</div>
</div>