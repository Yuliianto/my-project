

<style type="text/css">
	body{
		background: #4E58FF;
	}
</style>



<div class="container" style="margin-top:100px; ">
	<div class="row">
			<div class="col-md-8" style="margin: auto;">
				<div class="card">
					<div class="card-header" style="background:#fff;color: #444;">
						
						<h2>Register account<i class="btn btn-warning pull-right fa fa-times"> </i></h2>
					</div>
					<div class="card-body" style="background: #EBEDEF;color: #272822;">


						<div>
							<?php if (validation_errors()) : ?>
									<div class="alert alert-danger" role="alert">
										<?= validation_errors() ?>
									</div>
							<?php endif; ?>
							<?php if (isset($error)) : ?>
									<div class="alert alert-danger" role="alert">
										<?= $error ?>
									</div>
							<?php endif; ?>
						</div>
						
						<form class="" role="form" action='<?= base_url('index.php/web/register');?>' method="post">
							<div class="form-goup">
								<label for='username'>Username</label>
								<input type="text" name="username" class="form-control" placeholder="Enter Username" style="max-width: 220px;">
							</div>
							<div class="form-goup">
								<label for='email'>Email</label>
								<input type="email" name="email" class="form-control" placeholder="Enter email" style="max-width: 420px;">
							</div>
							<div class="form-goup">
								<label for='password'>Password</label>
								<input type="password" name="password" class="form-control" placeholder="Enter password" style="max-width: 320px;">
							</div>
							<div class="form-goup">
								<label for='paskonfirm'>Konfirm Password</label>
								<input type="password" name="password_confirm" class="form-control" placeholder="Enter Konfirm Password" style="max-width: 320px;">
							</div>
								<p class="help-block">Must match your password</p>
							<div class="form-goup">
							<input type="submit" name="regis" class="btn btn-primary">
							</div>
						</form>
					</div>
				</div>	
			</div>
	</div>
</div>